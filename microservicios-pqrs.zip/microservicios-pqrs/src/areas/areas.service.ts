import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Area } from './area.entity';

@Injectable()
export class AreasService {
  constructor(
    @InjectRepository(Area)
    private readonly areaRepo: Repository<Area>,
  ) {}

  crear(nombre: string) {
    const nueva = this.areaRepo.create({ nombre });
    return this.areaRepo.save(nueva);
  }

  listar() {
    return this.areaRepo.find();
  }

  eliminar(id: number) {
    return this.areaRepo.delete(id);
  }
}
