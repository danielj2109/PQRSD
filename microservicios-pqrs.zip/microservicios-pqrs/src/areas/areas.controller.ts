import { Controller, Post, Body, Get, Delete, Param } from '@nestjs/common';
import { AreasService } from './areas.service';

@Controller('areas')
export class AreasController {
  constructor(private readonly areasService: AreasService) {}

  @Post()
  crear(@Body('nombre') nombre: string) {
    return this.areasService.crear(nombre);
  }

  @Get()
  listar() {
    return this.areasService.listar();
  }

  @Delete(':id')
  eliminar(@Param('id') id: number) {
    return this.areasService.eliminar(id);
  }
}
