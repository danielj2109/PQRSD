import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Pqrs } from '../pqrs/pqrs.entity';
import { User } from 'src/users/user.entity';

@Entity()
export class Area {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nombre: string;
  
  @OneToMany(() => Pqrs, pqrs => pqrs.area)
  pqrs: Pqrs[];

  @OneToMany(() => User, user => user.area)
  user: User[];
}
