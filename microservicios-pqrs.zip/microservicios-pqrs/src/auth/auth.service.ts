import { Injectable } from '@nestjs/common';
import { UsersService } from '../users/users.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    private readonly usersService: UsersService,
    private readonly jwtService: JwtService,
  ) {}

  async validarUsuario(email: string, password: string) {
    const user = await this.usersService.buscarPorEmail(email);
    if (!user) return null;

    const passOK = await bcrypt.compare(password, user.password);
    if (!passOK) return null;

    return user;
  }

  async login(user: any) {
    const payload = { sub: user.id, email: user.email, rol: user.rol };

    return {
      token: this.jwtService.sign(payload),
      user,
    };
  }
}
