import { Controller, Post, Body, UnauthorizedException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { LoginDto } from './dto/login.dto';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() dto: LoginDto) {
    const user = await this.authService.validarUsuario(dto.email, dto.password);
    if (!user) throw new UnauthorizedException('Credenciales incorrectas');

    return this.authService.login(user);
  }
}
