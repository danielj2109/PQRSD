import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PqrsModule } from './pqrs/pqrs.module';
import { AreasModule } from './areas/areas.module';
import { UsersModule } from './users/users.module';
import { AuthModule } from './auth/auth.module';
import { APP_GUARD } from '@nestjs/core';
import { JwtAuthGuard } from './auth/jwt-auth.guard'; 
import { RolesGuard } from './auth/roles.guard';
import { SurveyModule } from './survey/survey.module';
import { DashboardModule } from './dashboard/dashboard.module';


@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'user',
      password: '0000',
      database: 'micro_pqrs',
      autoLoadEntities: true,
      synchronize: true,
    }),

    PqrsModule,
    AreasModule,
    UsersModule,
    AuthModule,
    SurveyModule,
    DashboardModule,
  ],

  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,  
    },
    {
      provide: APP_GUARD,
      useClass: RolesGuard,   
    },
  ],
})
export class AppModule {}
