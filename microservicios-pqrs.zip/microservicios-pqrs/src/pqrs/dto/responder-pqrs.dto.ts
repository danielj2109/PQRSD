import { IsNotEmpty, IsString } from 'class-validator';

export class ResponderPqrsDto {
  @IsNotEmpty()
  @IsString()
  respuesta: string;
}
