import { IsNotEmpty, IsString, IsEmail, IsNumber } from 'class-validator';

export class CreatePqrsDto {
  @IsString()
  @IsNotEmpty()
  nombre: string;

  @IsString()
  @IsNotEmpty()
  identificacion: string;

  @IsEmail()
  correo: string;

  @IsString()
  tipo: string;

  @IsString()
  medio: string;

  @IsString()
  descripcion: string;

  @IsString()
  prioridad: string;

  @IsNumber()
  areaId: number;
}
