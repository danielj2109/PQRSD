import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, OneToMany } from 'typeorm';
import { Area } from '../areas/area.entity';
import { Survey } from 'src/survey/survey.entity';

@Entity()
export class Pqrs {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  radicado: string;

  @Column()
  nombre: string;

  @Column()
  identificacion: string;

  @Column()
  correo: string;

  @Column()
  tipo: string;

  @Column()
  medio: string;

  @Column()
  descripcion: string;

  @Column()
  prioridad: string;

  @Column()
  estado: string;

  @Column()
  fecha_creacion: string;

  @Column()
  fecha_limite: string;

  @Column({ nullable: true })
  fecha_respuesta: string;
  
  @ManyToOne(() => Area, area => area.pqrs, { eager: true })
  area: Area;

  @OneToMany(() => Survey, survey => survey.pqrs)
  survey: Survey[];
}
