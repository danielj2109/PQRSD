import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pqrs } from './pqrs.entity';
import { Area } from '../areas/area.entity';
import { CreatePqrsDto } from './dto/create-pqrs.dto';

@Injectable()
export class PqrsService {
  constructor(
    @InjectRepository(Pqrs)
    private readonly pqrsRepo: Repository<Pqrs>,

    @InjectRepository(Area)
    private readonly areaRepo: Repository<Area>,
  ) {}

  async crearPqrs(data: CreatePqrsDto): Promise<Pqrs> {
    const area = await this.areaRepo.findOne({ where: { id: data.areaId } });

    if (!area) {
      throw new Error(`El área con ID ${data.areaId} no existe`);
    }

    const fecha = new Date();
    const radicado = `${fecha.getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`;

    const nuevaPqrs = this.pqrsRepo.create({
      ...data,
      radicado,
      estado: 'Pendiente',
      fecha_creacion: fecha.toISOString(),
      fecha_limite: new Date(fecha.getTime() + 10 * 24 * 60 * 60 * 1000).toISOString(),
      area,
    });

    return this.pqrsRepo.save(nuevaPqrs);
  }

  listarPqrs() {
    return this.pqrsRepo.find({ relations: ['area'] });
  }

  async actualizarEstado(id: number, estado: string) {
    await this.pqrsRepo.update(id, { estado });
    return { mensaje: `Estado actualizado a ${estado}` };
  }

  async eliminarPqrs(id: number) {
    await this.pqrsRepo.delete(id);
    return { mensaje: `PQRS eliminada` };
  }

  async responderPqrs(id: number, respuesta: string) {
    const fecha_respuesta = new Date().toISOString();

    await this.pqrsRepo.update(id, {
      estado: 'Respondida',
      fecha_respuesta,
      descripcion: respuesta,
    });

    return { message: `PQRS #${id} respondida correctamente` };
  }

  async buscarPorRadicado(radicado: string) {
    return this.pqrsRepo.findOne({
      where: { radicado },
      relations: ['area'],
    });
  }

  async reasignarArea(id: number, areaId: number) {
    const area = await this.areaRepo.findOne({ where: { id: areaId } });

    if (!area) {
      throw new Error(`El área con ID ${areaId} no existe`);
    }

    await this.pqrsRepo.update(id, { area });

    return { mensaje: `PQRS reasignada al área ${area.nombre}` };
  }
}
