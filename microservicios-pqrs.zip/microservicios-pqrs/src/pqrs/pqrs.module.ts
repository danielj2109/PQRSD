import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Pqrs } from './pqrs.entity';
import { PqrsService } from './pqrs.service';
import { PqrsController } from './pqrs.controller';
import { Area } from '../areas/area.entity';
import { AreasModule } from '../areas/areas.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Pqrs, Area]), 
    AreasModule, 
  ],
  controllers: [PqrsController],
  providers: [PqrsService],
  exports: [PqrsService],
})
export class PqrsModule {}
