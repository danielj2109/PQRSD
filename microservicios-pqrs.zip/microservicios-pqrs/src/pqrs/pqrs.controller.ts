import { Controller, Post, Get, Patch, Delete, Body, Param } from '@nestjs/common';
import { PqrsService } from './pqrs.service';
import { CreatePqrsDto } from './dto/create-pqrs.dto';
import { ResponderPqrsDto } from './dto/responder-pqrs.dto';
import { Public } from '../auth/public.decorator';
import { Roles } from '../auth/roles.decorator';

@Controller('pqrs')
export class PqrsController {
  constructor(private readonly pqrsService: PqrsService) {}
  @Public()
  @Post()
  crear(@Body() dto: CreatePqrsDto) {
    return this.pqrsService.crearPqrs(dto);
  }

  @Public()
  @Get('radicado/:radicado')
  buscarPorRadicado(@Param('radicado') radicado: string) {
    return this.pqrsService.buscarPorRadicado(radicado);
  }

  @Roles('admin', 'funcionario')
  @Get()
  listar() {
    return this.pqrsService.listarPqrs();
  }

  @Roles('admin', 'funcionario')
  @Patch(':id')
  actualizar(@Param('id') id: number, @Body('estado') estado: string) {
    return this.pqrsService.actualizarEstado(id, estado);
  }

  @Roles('admin', 'funcionario')
  @Patch('responder/:id')
  responder(@Param('id') id: number, @Body() dto: ResponderPqrsDto) {
    return this.pqrsService.responderPqrs(id, dto.respuesta);
  }

  @Roles('admin')
  @Delete(':id')
  eliminar(@Param('id') id: number) {
    return this.pqrsService.eliminarPqrs(id);
  }

}
