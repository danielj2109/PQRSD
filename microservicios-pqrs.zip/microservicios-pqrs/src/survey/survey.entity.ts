import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Pqrs } from '../pqrs/pqrs.entity';

@Entity()
export class Survey {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  calificacion: number; 

  @Column({ nullable: true })
  comentario: string;

  @Column()
  fecha: string;

  @ManyToOne(() => Pqrs, pqrs => pqrs.survey, { onDelete: 'CASCADE' })
  pqrs: Pqrs;
}
