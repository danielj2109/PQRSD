import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateSurveyDto {
  @IsNumber()
  calificacion: number;

  @IsString()
  comentario: string;

  @IsNumber()
  pqrsId: number;
}
