import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Survey } from './survey.entity';
import { CreateSurveyDto } from './dto/create-survey.dto';
import { Pqrs } from '../pqrs/pqrs.entity';

@Injectable()
export class SurveyService {
  constructor(
    @InjectRepository(Survey)
    private surveyRepo: Repository<Survey>,

    @InjectRepository(Pqrs)
    private pqrsRepo: Repository<Pqrs>,
  ) {}

  async crearEncuesta(dto: CreateSurveyDto) {
    const pqrs = await this.pqrsRepo.findOne({ where: { id: dto.pqrsId } });

    if (!pqrs) {
      throw new Error(`La PQRS con ID ${dto.pqrsId} no existe`);
    }

    const encuesta = this.surveyRepo.create({
      calificacion: dto.calificacion,
      comentario: dto.comentario,
      fecha: new Date().toISOString(),
      pqrs,
    });

    return this.surveyRepo.save(encuesta);
  }

  listar() {
    return this.surveyRepo.find({ relations: ['pqrs'] });
  }
}
