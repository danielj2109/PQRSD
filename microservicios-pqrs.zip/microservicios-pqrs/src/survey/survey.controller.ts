import { Controller, Post, Get, Body } from '@nestjs/common';
import { SurveyService } from './survey.service';
import { CreateSurveyDto } from './dto/create-survey.dto';

@Controller('encuestas')
export class SurveyController {
  constructor(private readonly surveyService: SurveyService) {}

  @Post()
  crear(@Body() dto: CreateSurveyDto) {
    return this.surveyService.crearEncuesta(dto);
  }

  @Get()
  listar() {
    return this.surveyService.listar();
  }
}
