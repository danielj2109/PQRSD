import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import { Area } from '../areas/area.entity';
import { CreateUserDto } from './dto/create-user.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private readonly userRepo: Repository<User>,

    @InjectRepository(Area)
    private readonly areaRepo: Repository<Area>,
  ) {}

  async crear(dto: CreateUserDto) {
  let area: Area | null = null;

  if (dto.areaId) {
    area = await this.areaRepo.findOne({ where: { id: dto.areaId } });
    if (!area) throw new Error('El área no existe');
  }

  const nuevo = this.userRepo.create({
    ...dto,
    area,
  });

  return this.userRepo.save(nuevo);
}

  listar() {
    return this.userRepo.find({ relations: ['area'] });
  }

  findByEmail(email: string) {
  return this.userRepo.findOne({ where: { email }, relations: ['area'] });
}
async buscarPorEmail(email: string) {
  return this.userRepo.findOne({
    where: { email },
    relations: ['area'], 
  });
}

}
