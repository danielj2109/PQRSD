import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Pqrs } from '../pqrs/pqrs.entity';
import { Survey } from '../survey/survey.entity';
import { Area } from '../areas/area.entity';

@Injectable()
export class DashboardService {
  constructor(
    @InjectRepository(Pqrs)
    private readonly pqrsRepo: Repository<Pqrs>,
    
    @InjectRepository(Survey)
    private readonly surveyRepo: Repository<Survey>,

    @InjectRepository(Area)
    private readonly areaRepo: Repository<Area>,
  ) {}

  async obtenerDatos() {
    const totalPqrs = await this.pqrsRepo.count();

    const pqrsPorEstado = await this.pqrsRepo
      .createQueryBuilder('pqrs')
      .select('pqrs.estado', 'estado')
      .addSelect('COUNT(*)', 'total')
      .groupBy('pqrs.estado')
      .getRawMany();

    const pqrsPorArea = await this.pqrsRepo
      .createQueryBuilder('pqrs')
      .leftJoin('pqrs.area', 'area')
      .select('area.nombre', 'area')
      .addSelect('COUNT(*)', 'total')
      .groupBy('area.nombre')
      .getRawMany();

    const totalEncuestas = await this.surveyRepo.count();

    const promedioCalificacion = await this.surveyRepo
      .createQueryBuilder('encuesta')
      .select('AVG(encuesta.calificacion)', 'promedio')
      .getRawOne();

    return {
      totalPqrs,
      pqrsPorEstado,
      pqrsPorArea,
      totalEncuestas,
      promedioCalificacion: Number(promedioCalificacion.promedio || 0),
    };
  }
}
