import { Module } from '@nestjs/common';
import { DashboardService } from './dashboard.service';
import { DashboardController } from './dashboard.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Pqrs } from '../pqrs/pqrs.entity';
import { Survey } from '../survey/survey.entity';
import { Area } from '../areas/area.entity';

@Module({
  imports: [TypeOrmModule.forFeature([Pqrs, Survey, Area])],
  controllers: [DashboardController],
  providers: [DashboardService],
})
export class DashboardModule {}
